package com.kuminov.audiosplitter;

import android.app.*;
import android.content.*;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.*;
import java.util.*;

public class PlaybackService extends Service {
    public static final String ACTION_PLAY="PLAY", ACTION_PAUSE="PAUSE", ACTION_STOP="STOP", ACTION_SEEK="SEEK", ACTION_VOLUME="VOLUME", ACTION_SLEEP="SLEEP", ACTION_RESUME="RESUME";
    private static final int NOTIF=78;
    private MediaPlayer player;
    private Uri uri;
    private String name="Audio Splitter";
    private int volume=80;
    private Handler handler=new Handler(Looper.getMainLooper());
    private Runnable ticker, sleepTask;
    private PowerManager.WakeLock wakeLock;
    private SharedPreferences prefs;

    @Override public void onCreate(){super.onCreate();prefs=getSharedPreferences("player",MODE_PRIVATE);volume=prefs.getInt("volume",80);if(Build.VERSION.SDK_INT>=26){NotificationChannel c=new NotificationChannel("player","Плеер Audio Splitter",NotificationManager.IMPORTANCE_LOW);((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(c);}PowerManager pm=(PowerManager)getSystemService(POWER_SERVICE);wakeLock=pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK,"AudioSplitter:Playback");}
    @Override public int onStartCommand(Intent i,int flags,int id){if(i==null)return START_STICKY;String a=i.getAction();if(ACTION_PLAY.equals(a)){String s=i.getStringExtra("uri");if(s!=null){uri=Uri.parse(s);name=i.getStringExtra("name");if(name==null)name="Audio";int pos=i.getIntExtra("position",0);play(pos);}}else if(ACTION_PAUSE.equals(a))pause();else if(ACTION_STOP.equals(a))stopPlayback();else if(ACTION_SEEK.equals(a)){if(player!=null)try{player.seekTo(Math.max(0,i.getIntExtra("position",0)));broadcast();}catch(Exception ignored){}}else if(ACTION_VOLUME.equals(a)){volume=i.getIntExtra("volume",80);applyVolume();}else if(ACTION_SLEEP.equals(a)){int mins=i.getIntExtra("minutes",0);setSleep(mins);}else if(ACTION_RESUME.equals(a)){String s=prefs.getString("uri",null);if(s!=null){uri=Uri.parse(s);name=prefs.getString("name","Audio");play(prefs.getInt("position",0));}}return START_STICKY;}
    private void play(int pos){releasePlayer();if(Build.VERSION.SDK_INT>=26)startForeground(NOTIF,notification());try{player=new MediaPlayer();player.setDataSource(this,uri);player.setOnPreparedListener(mp->{mp.setVolume(volume/100f,volume/100f);if(pos>0)mp.seekTo(pos);mp.start();if(!wakeLock.isHeld())wakeLock.acquire();save();startForeground(NOTIF,notification());startTicker();broadcast();});player.setOnCompletionListener(mp->{prefs.edit().putInt("position",0).apply();broadcast();});player.setOnErrorListener((mp,w,e)->{send("Ошибка воспроизведения: "+w+"/"+e);stopPlayback();return true;});player.prepareAsync();}catch(Exception e){send("Не удалось открыть трек: "+e.getMessage());stopPlayback();}}
    private void pause(){if(player!=null)try{if(player.isPlaying())player.pause();save();if(wakeLock.isHeld())wakeLock.release();broadcast();((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).notify(NOTIF,notification());}catch(Exception ignored){}}
    private void stopPlayback(){save();releasePlayer();if(wakeLock.isHeld())wakeLock.release();stopTicker();stopForeground(true);broadcast();}
    private void releasePlayer(){if(player!=null){try{player.stop();}catch(Exception ignored){}try{player.release();}catch(Exception ignored){}player=null;}}
    private void applyVolume(){if(player!=null)player.setVolume(volume/100f,volume/100f);prefs.edit().putInt("volume",volume).apply();}
    private void save(){if(uri!=null){int p=0;if(player!=null)try{p=player.getCurrentPosition();}catch(Exception ignored){}prefs.edit().putString("uri",uri.toString()).putString("name",name).putInt("position",p).putInt("volume",volume).apply();}}
    private void startTicker(){stopTicker();ticker=new Runnable(){public void run(){save();broadcast();if(player!=null&&player.isPlaying())handler.postDelayed(this,700);}};handler.post(ticker);}
    private void stopTicker(){if(ticker!=null)handler.removeCallbacks(ticker);ticker=null;}
    private void setSleep(int mins){if(sleepTask!=null)handler.removeCallbacks(sleepTask);if(mins>0){sleepTask=()->{pause();send("Таймер сна: воспроизведение приостановлено");};handler.postDelayed(sleepTask,mins*60_000L);send("Таймер сна установлен: "+mins+" мин.");}else send("Таймер сна отключён");}
    private Notification notification(){Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(this,"player"):new Notification.Builder(this);Intent open=new Intent(this,MainActivity.class);PendingIntent pi=PendingIntent.getActivity(this,1,open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);Intent pauseIntent=new Intent(this,PlaybackService.class);pauseIntent.setAction(ACTION_PAUSE);PendingIntent pausePi=PendingIntent.getService(this,2,pauseIntent,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);Intent stopIntent=new Intent(this,PlaybackService.class);stopIntent.setAction(ACTION_STOP);PendingIntent stopPi=PendingIntent.getService(this,3,stopIntent,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);b.addAction(new Notification.Action.Builder(android.R.drawable.ic_media_pause,"Пауза",pausePi).build());b.addAction(new Notification.Action.Builder(android.R.drawable.ic_media_stop,"Стоп",stopPi).build());return b.setSmallIcon(android.R.drawable.ic_media_play).setContentTitle("Audio Splitter Winamp").setContentText(name+(player!=null&&player.isPlaying()?" — воспроизведение":" — пауза")).setContentIntent(pi).setOngoing(player!=null&&player.isPlaying()).build();}
    private void broadcast(){Intent i=new Intent("PLAYER_STATE");i.setPackage(getPackageName());i.putExtra("name",name);i.putExtra("position",player==null?prefs.getInt("position",0):safePosition());i.putExtra("duration",safeDuration());i.putExtra("playing",player!=null&&player.isPlaying());i.putExtra("volume",volume);sendBroadcast(i);if(player!=null)((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).notify(NOTIF,notification());}
    private int safePosition(){try{return player.getCurrentPosition();}catch(Exception e){return 0;}} private int safeDuration(){try{return player.getDuration();}catch(Exception e){return 0;}}
    private void send(String s){Intent i=new Intent("PLAYER_MESSAGE");i.setPackage(getPackageName());i.putExtra("message",s);sendBroadcast(i);}
    @Override public void onTaskRemoved(Intent rootIntent){save();super.onTaskRemoved(rootIntent);}
    @Override public void onDestroy(){save();stopTicker();if(sleepTask!=null)handler.removeCallbacks(sleepTask);releasePlayer();if(wakeLock.isHeld())wakeLock.release();super.onDestroy();}
    @Override public IBinder onBind(Intent i){return null;}
}
