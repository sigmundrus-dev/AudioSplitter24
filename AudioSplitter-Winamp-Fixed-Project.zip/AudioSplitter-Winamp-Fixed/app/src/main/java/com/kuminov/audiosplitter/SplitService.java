package com.kuminov.audiosplitter;

import android.app.*;import android.content.*;import android.net.Uri;import android.os.*;import androidx.documentfile.provider.DocumentFile;import com.arthenica.ffmpegkit.*;import java.util.*;

public class SplitService extends Service {
    static final int NOTIF=77; volatile boolean running=false,cancelled=false; volatile long currentSession=-1; Uri input,folder; int minutes,overlap; String bitrate,format;
    @Override public void onCreate(){super.onCreate();if(Build.VERSION.SDK_INT>=26){NotificationChannel ch=new NotificationChannel("split","Audio Splitter",NotificationManager.IMPORTANCE_LOW);((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(ch);}}
    Notification note(String s,int p){Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(this,"split"):new Notification.Builder(this);return b.setContentTitle("Audio Splitter Winamp").setContentText(s).setSmallIcon(android.R.drawable.ic_media_play).setProgress(100,Math.max(0,p),false).build();}
    @Override public int onStartCommand(Intent i,int flags,int id){if(i==null)return START_NOT_STICKY;if("CANCEL".equals(i.getAction())){cancelled=true;if(currentSession>0)FFmpegKit.cancel(currentSession);broadcastProgress(0,"Отмена…",false);return START_NOT_STICKY;}if("START".equals(i.getAction())){if(running){broadcastProgress(0,"Нарезка уже выполняется",false);return START_NOT_STICKY;}input=Uri.parse(i.getStringExtra("input"));folder=Uri.parse(i.getStringExtra("folder"));minutes=i.getIntExtra("minutes",30);overlap=i.getIntExtra("overlap",0);bitrate=i.getStringExtra("bitrate");format=i.getStringExtra("format");cancelled=false;if(Build.VERSION.SDK_INT>=26)startForeground(NOTIF,note("Подготовка…",0));new Thread(this::work,"audio-split-worker").start();}return START_NOT_STICKY;}
    void work(){running=true;try{
        String in=FFmpegKitConfig.getSafParameterForRead(this,input);if(in==null||in.trim().isEmpty())throw new Exception("Не удалось открыть исходный файл через Android Storage Access Framework");
        MediaInformationSession probe=FFprobeKit.getMediaInformation(in);if(probe==null||!ReturnCode.isSuccess(probe.getReturnCode())||probe.getMediaInformation()==null)throw new Exception("FFprobe не смог прочитать файл. Поддерживаемые форматы: MP3 и M4A.");
        String ds=probe.getMediaInformation().getDuration();double durationSec;try{durationSec=Double.parseDouble(ds);}catch(Exception e){throw new Exception("FFprobe не вернул длительность аудио: "+ds);}if(!Double.isFinite(durationSec)||durationSec<=0)throw new Exception("Длительность аудио равна нулю или не определена");
        long total=(long)(durationSec*1000);long step=minutes*60_000L;int count=(int)Math.ceil((double)total/step);if(count<1||count>10000)throw new Exception("Недопустимое количество частей: "+count);
        DocumentFile dir=DocumentFile.fromTreeUri(this,folder);if(dir==null||!dir.canWrite())throw new Exception("Нет доступа на запись в выбранную папку. Выбери папку заново.");
        String base=safeName(stripExtension(displayName(input)));String ext=format.equals("M4A")?"m4a":"mp3";
        for(int n=0;n<count;n++){if(cancelled)throw new Exception("Нарезка отменена пользователем");long start=n==0?0:Math.max(0,n*step-overlap*1000L);long end=Math.min(total,(n+1)*step);long len=Math.max(1,end-start);String name=String.format(Locale.US,"%03d_%s.%s",n+1,base,ext);
            DocumentFile old=dir.findFile(name);if(old!=null){if(!old.delete())throw new Exception("Не удалось перезаписать существующий файл: "+name);}DocumentFile out=dir.createFile(ext.equals("m4a")?"audio/mp4":"audio/mpeg",name);if(out==null)throw new Exception("Android не смог создать файл "+name+" в выбранной папке");
            String outSaf=FFmpegKitConfig.getSafParameterForWrite(this,out.getUri());if(outSaf==null||outSaf.isEmpty())throw new Exception("Не удалось передать выходной файл FFmpeg: "+name);
            String codec=ext.equals("mp3")?"-c:a libmp3lame -b:a "+bitrate+" -ar 44100":"-c:a aac -b:a "+bitrate+" -movflags +faststart";
            String cmd="-hide_banner -y -ss "+sec(start)+" -i "+quote(in)+" -t "+sec(len)+" -vn "+codec+" "+quote(outSaf);
            broadcastProgress((int)(n*100.0/count),"Создание части "+(n+1)+" из "+count+"…",false);FFmpegSession session=FFmpegKit.execute(cmd);currentSession=session.getSessionId();
            if(cancelled||ReturnCode.isCancel(session.getReturnCode())){out.delete();throw new Exception("Нарезка отменена пользователем");}
            if(!ReturnCode.isSuccess(session.getReturnCode())){String logs=session.getFailStackTrace();if(logs==null||logs.trim().isEmpty())logs=session.getOutput();out.delete();throw new Exception("FFmpeg не создал "+name+". "+shortError(logs));}
            long actual=Math.max(0,len);Intent t=new Intent("SPLIT_TRACK");t.setPackage(getPackageName());t.putExtra("name",name);t.putExtra("uri",out.getUri().toString());t.putExtra("duration",actual);sendBroadcast(t);broadcastProgress((int)((n+1)*100.0/count),"Создано: "+name,false);
        }broadcastProgress(100,"Готово! Создано файлов: "+count,true);
    }catch(Exception e){broadcastProgress(0,"Ошибка: "+e.getMessage(),true);}finally{running=false;currentSession=-1;stopForeground(true);stopSelf();}}
    String sec(long ms){return String.format(Locale.US,"%.3f",ms/1000.0);}String quote(String s){return "'"+s.replace("'","'\\''")+"'";}
    String shortError(String s){if(s==null||s.trim().isEmpty())return "Подробности FFmpeg отсутствуют.";String[] a=s.split("\\r?\\n");StringBuilder b=new StringBuilder();for(int i=Math.max(0,a.length-8);i<a.length;i++){if(a[i].trim().length()>0){if(b.length()>0)b.append(" | ");b.append(a[i].trim());}}return b.toString();}
    String displayName(Uri u){try(android.database.Cursor c=getContentResolver().query(u,null,null,null,null)){if(c!=null&&c.moveToFirst()){int i=c.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME);if(i>=0)return c.getString(i);}}catch(Exception ignored){}return u.getLastPathSegment()==null?"audio":u.getLastPathSegment();}
    String stripExtension(String s){int p=s.lastIndexOf('.');return p>0?s.substring(0,p):s;}String safeName(String s){String x=s==null?"audio":s.replaceAll("[^a-zA-Z0-9А-Яа-я._-]","_");return x.isEmpty()?"audio":x;}
    void broadcastProgress(int p,String s,boolean done){Intent i=new Intent("SPLIT_PROGRESS");i.setPackage(getPackageName());i.putExtra("p",p);i.putExtra("s",s);i.putExtra("finished",done);sendBroadcast(i);if(Build.VERSION.SDK_INT>=26)((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).notify(NOTIF,note(s,p));}
    @Override public android.os.IBinder onBind(Intent i){return null;}
}
