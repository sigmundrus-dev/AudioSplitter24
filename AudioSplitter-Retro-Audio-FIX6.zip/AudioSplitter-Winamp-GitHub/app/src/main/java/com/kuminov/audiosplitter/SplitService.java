package com.kuminov.audiosplitter;

import android.app.*;
import android.content.*;
import android.net.Uri;
import android.os.*;
import androidx.documentfile.provider.DocumentFile;
import com.arthenica.ffmpegkit.*;
import java.io.*;
import java.util.*;

public class SplitService extends Service {
    static final int NOTIF = 77;
    volatile boolean running = false, cancelled = false, pauseRequested = false, stopRequested = false;
    volatile long currentSession = -1;
    Uri input, folder;
    int minutes, overlap;
    String bitrate, format;
    int completedParts = 0;
    volatile int totalParts = 0, currentPart = 0;
    private final Object pauseMonitor = new Object();
    private PowerManager.WakeLock conversionWakeLock;

    @Override public void onCreate() {
        super.onCreate();
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel ch = new NotificationChannel("split", "Audio Splitter", NotificationManager.IMPORTANCE_LOW);
            ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(ch);
            NotificationChannel doneChannel = new NotificationChannel("split_done", "Завершение конвертации", NotificationManager.IMPORTANCE_DEFAULT);
            doneChannel.setDescription("Уведомление после завершения нарезки аудио");
            ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(doneChannel);
        }
    }

    Notification note(String s, int p) {
        Notification.Builder b = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(this, "split") : new Notification.Builder(this);
        return b.setContentTitle("Audio Splitter").setContentText(s)
                .setSmallIcon(android.R.drawable.ic_media_play)
                .setProgress(100, Math.max(0, p), false).build();
    }

    @Override public int onStartCommand(Intent i, int flags, int id) {
        if (i == null) return START_NOT_STICKY;
        if ("PAUSE".equals(i.getAction())) {
            pauseRequested = true;
            broadcastProgress(0, "Пауза запрошена — завершится текущая часть", false);
            return START_NOT_STICKY;
        }
        if ("RESUME_PAUSED".equals(i.getAction())) {
            pauseRequested = false;
            synchronized (pauseMonitor) { pauseMonitor.notifyAll(); }
            broadcastProgress(0, "Продолжаю конвертацию…", false);
            return START_NOT_STICKY;
        }
        if ("STOP_AT_BOUNDARY".equals(i.getAction())) {
            stopRequested = true;
            pauseRequested = false;
            synchronized (pauseMonitor) { pauseMonitor.notifyAll(); }
            broadcastProgress(0, "Остановка после текущей части…", false);
            return START_NOT_STICKY;
        }
        if ("CANCEL".equals(i.getAction())) {
            stopRequested = true;
            pauseRequested = false;
            synchronized (pauseMonitor) { pauseMonitor.notifyAll(); }
            broadcastProgress(0, "Остановка после текущей части…", false);
            return START_NOT_STICKY;
        }
        if ("START".equals(i.getAction()) || "RESUME_JOB".equals(i.getAction())) {
            if (running) {
                broadcastProgress(0, "Нарезка уже выполняется", false);
                return START_NOT_STICKY;
            }
            input = Uri.parse(i.getStringExtra("input"));
            folder = Uri.parse(i.getStringExtra("folder"));
            minutes = i.getIntExtra("minutes", 30);
            overlap = i.getIntExtra("overlap", 0);
            bitrate = i.getStringExtra("bitrate");
            format = i.getStringExtra("format");
            cancelled = false;
            pauseRequested = false;
            stopRequested = false;
            android.content.SharedPreferences cp = getSharedPreferences("split_checkpoint", MODE_PRIVATE);
            boolean resumeJob = "RESUME_JOB".equals(i.getAction());
            completedParts = resumeJob ? cp.getInt("completed", 0) : 0;
            totalParts = 0; currentPart = completedParts + 1;
            cp.edit().putString("input", input.toString()).putString("folder", folder.toString())
                    .putInt("minutes", minutes).putInt("overlap", overlap).putString("bitrate", bitrate)
                    .putString("format", format).putBoolean("available", true).putBoolean("active", true)
                    .putBoolean("finished", false).putInt("ui_progress", 0).putString("ui_message", "Подготовка FFmpeg…")
                    .putInt("total", 0).putInt("current", completedParts + 1).apply();
            if (Build.VERSION.SDK_INT >= 26) startForeground(NOTIF, note("Подготовка…", 0));
            // Keep the CPU awake while FFmpeg is copying/encoding audio, even with the screen off.
            // The lock is released in work()'s finally block and has a safety timeout.
            PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
            if (pm != null) {
                if (conversionWakeLock != null && conversionWakeLock.isHeld()) {
                    conversionWakeLock.release();
                }
                conversionWakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK,
                        getPackageName() + ":AudioConversion");
                conversionWakeLock.setReferenceCounted(false);
                conversionWakeLock.acquire(12L * 60L * 60L * 1000L);
            }
            new Thread(this::work, "audio-split-worker").start();
        }
        return START_NOT_STICKY;
    }

    void work() {
        running = true;
        File inputTemp = null;
        try {
            // Avoid passing Android SAF pseudo-paths (such as saf:1.m4a) to FFmpeg.
            // Copy the selected content URI into app cache and give FFmpeg a real file path.
            inputTemp = copyUriToCache(input, "audio_input", inputSuffix(input));
            String in = inputTemp.getAbsolutePath();

            MediaInformationSession probe = FFprobeKit.getMediaInformation(in);
            if (probe == null || !ReturnCode.isSuccess(probe.getReturnCode()) || probe.getMediaInformation() == null) {
                throw new Exception("FFprobe не смог прочитать выбранный файл. Проверь, что это MP3 или M4A и файл полностью доступен.");
            }
            String ds = probe.getMediaInformation().getDuration();
            double durationSec;
            try { durationSec = Double.parseDouble(ds); }
            catch (Exception e) { throw new Exception("FFprobe не вернул длительность аудио: " + ds); }
            if (!Double.isFinite(durationSec) || durationSec <= 0) throw new Exception("Длительность аудио равна нулю или не определена");

            long total = (long)(durationSec * 1000);
            long step = minutes * 60_000L;
            int count = (int)Math.ceil((double)total / step);
            if (count < 1 || count > 10000) throw new Exception("Недопустимое количество частей: " + count);
            if (completedParts < 0 || completedParts > count) completedParts = 0;
            totalParts = count;
            currentPart = Math.min(count, completedParts + 1);
            getSharedPreferences("split_checkpoint", MODE_PRIVATE).edit().putInt("total", count).putInt("current", currentPart).apply();
            broadcastProgress((int)(completedParts * 100.0 / count), "Подготовлено частей: " + count + ". Готово " + completedParts + " из " + count, false);

            DocumentFile dir = DocumentFile.fromTreeUri(this, folder);
            if (dir == null || !dir.canWrite()) throw new Exception("Нет доступа на запись в выбранную папку. Выбери папку заново.");

            String base = safeName(stripExtension(displayName(input)));
            String ext = "M4A".equalsIgnoreCase(format) ? "m4a" : "mp3";
            String mime = ext.equals("m4a") ? "audio/mp4" : "audio/mpeg";

            for (int n = completedParts; n < count; n++) {
                currentPart = n + 1;
                getSharedPreferences("split_checkpoint", MODE_PRIVATE).edit().putInt("current", currentPart).apply();
                waitIfPaused();
                if (stopRequested || cancelled) break;
                long start = n == 0 ? 0 : Math.max(0, n * step - overlap * 1000L);
                long end = Math.min(total, (n + 1) * step);
                long len = Math.max(1, end - start);
                String name = String.format(Locale.US, "%03d_%s.%s", n + 1, base, ext);

                DocumentFile old = dir.findFile(name);
                if (old != null && !old.delete()) throw new Exception("Не удалось перезаписать существующий файл: " + name);
                DocumentFile out = dir.createFile(mime, name);
                if (out == null) throw new Exception("Android не смог создать файл " + name + " в выбранной папке");

                File tempOut = File.createTempFile("audio_part_", "." + ext, getCacheDir());
                try {
                    String codec = ext.equals("mp3")
                            ? "-c:a libmp3lame -b:a " + bitrate + " -ar 44100"
                            : "-c:a aac -b:a " + bitrate + " -movflags +faststart";
                    String cmd = "-hide_banner -y -ss " + sec(start) + " -i " + quote(in)
                            + " -t " + sec(len) + " -vn " + codec + " " + quote(tempOut.getAbsolutePath());
                    broadcastProgress((int)(completedParts * 100.0 / count), "Готово " + completedParts + " из " + count + ". Обрабатывается часть " + (n + 1) + " из " + count + "…", false);
                    FFmpegSession session = FFmpegKit.execute(cmd);
                    currentSession = session.getSessionId();

                    if (cancelled || ReturnCode.isCancel(session.getReturnCode())) {
                        out.delete();
                        throw new Exception("Нарезка отменена пользователем");
                    }
                    if (!ReturnCode.isSuccess(session.getReturnCode())) {
                        String logs = session.getFailStackTrace();
                        if (logs == null || logs.trim().isEmpty()) logs = session.getOutput();
                        out.delete();
                        throw new Exception("FFmpeg не создал " + name + ". " + shortError(logs));
                    }
                    if (!tempOut.isFile() || tempOut.length() == 0) {
                        out.delete();
                        throw new Exception("FFmpeg завершился без ошибки, но временный файл пуст: " + name);
                    }

                    // Copy the completed local file to the user-selected Android folder via ContentResolver.
                    copyFileToUri(tempOut, out.getUri());
                    Intent t = new Intent("SPLIT_TRACK");
                    t.setPackage(getPackageName());
                    t.putExtra("name", name);
                    t.putExtra("uri", out.getUri().toString());
                    t.putExtra("duration", len);
                    sendBroadcast(t);
                    completedParts = n + 1;
                    currentPart = Math.min(count, completedParts + 1);
                    getSharedPreferences("split_checkpoint", MODE_PRIVATE).edit().putInt("completed", completedParts).putInt("total", count).putInt("current", currentPart).apply();
                    broadcastProgress((int)(completedParts * 100.0 / count), "Готово " + completedParts + " из " + count + " треков. Последний: " + name, false);
                } catch (Exception e) {
                    if (out.exists() && out.length() == 0) out.delete();
                    throw e;
                } finally {
                    //noinspection ResultOfMethodCallIgnored
                    tempOut.delete();
                }
            }
            if (completedParts >= count) {
                getSharedPreferences("split_checkpoint", MODE_PRIVATE).edit().putBoolean("available", false).putInt("completed", 0).apply();
                broadcastProgress(100, "Готово! Создано частей: " + count, true);
            } else if (stopRequested || cancelled) {
                broadcastProgress((int)(completedParts * 100.0 / Math.max(1, count)), "Остановлено. Готовых частей: " + completedParts + ". Нажми «Продолжить» для возобновления.", true);
            } else {
                broadcastProgress((int)(completedParts * 100.0 / Math.max(1, count)), "Пауза. Готовых частей: " + completedParts, false);
            }
        } catch (Exception e) {
            broadcastProgress((int)(completedParts * 100.0 / Math.max(1, completedParts + 1)), "Ошибка: " + e.getMessage(), true);
        } finally {
            if (inputTemp != null) {
                //noinspection ResultOfMethodCallIgnored
                inputTemp.delete();
            }
            running = false;
            currentSession = -1;
            if (conversionWakeLock != null && conversionWakeLock.isHeld()) {
                conversionWakeLock.release();
            }
            conversionWakeLock = null;
            stopForeground(true);
            stopSelf();
        }
    }

    void waitIfPaused() throws InterruptedException {
        synchronized (pauseMonitor) {
            while (pauseRequested && !stopRequested && !cancelled) {
                broadcastProgress(0, "ПАУЗА — готовых частей: " + completedParts + ". Нажми «Продолжить».", false);
                pauseMonitor.wait(1000L);
            }
        }
    }

    File copyUriToCache(Uri uri, String prefix, String suffix) throws Exception {
        if (uri == null) throw new Exception("Исходный файл не выбран");
        File file = File.createTempFile(prefix, suffix, getCacheDir());
        try (InputStream in = getContentResolver().openInputStream(uri);
             OutputStream out = new FileOutputStream(file)) {
            if (in == null) throw new Exception("Android не смог открыть исходный файл");
            byte[] buffer = new byte[1024 * 1024];
            int read;
            while ((read = in.read(buffer)) != -1) {
                if (cancelled) throw new Exception("Нарезка отменена пользователем");
                out.write(buffer, 0, read);
            }
            out.flush();
        } catch (Exception e) {
            //noinspection ResultOfMethodCallIgnored
            file.delete();
            throw e;
        }
        if (file.length() == 0) {
            //noinspection ResultOfMethodCallIgnored
            file.delete();
            throw new Exception("Исходный файл пуст или недоступен");
        }
        return file;
    }

    void copyFileToUri(File source, Uri destination) throws Exception {
        try (InputStream in = new FileInputStream(source);
             OutputStream out = getContentResolver().openOutputStream(destination, "w")) {
            if (out == null) throw new Exception("Android не открыл созданный файл для записи");
            byte[] buffer = new byte[1024 * 256];
            int read;
            while ((read = in.read(buffer)) != -1) out.write(buffer, 0, read);
            out.flush();
        } catch (Exception e) {
            throw new Exception("Не удалось сохранить готовый файл в выбранную папку: " + e.getMessage(), e);
        }
    }

    String inputSuffix(Uri uri) {
        String name = displayName(uri);
        int dot = name.lastIndexOf('.');
        String ext = dot >= 0 ? name.substring(dot).toLowerCase(Locale.ROOT) : ".audio";
        if (!ext.matches("\\.[a-z0-9]{1,8}")) return ".audio";
        return ext;
    }
    String sec(long ms) { return String.format(Locale.US, "%.3f", ms / 1000.0); }
    String quote(String s) { return "'" + s.replace("'", "'\\''") + "'"; }
    String shortError(String s) {
        if (s == null || s.trim().isEmpty()) return "Подробности FFmpeg отсутствуют.";
        String[] a = s.split("\\r?\\n");
        StringBuilder b = new StringBuilder();
        for (int i = Math.max(0, a.length - 8); i < a.length; i++) {
            if (a[i].trim().length() > 0) {
                if (b.length() > 0) b.append(" | ");
                b.append(a[i].trim());
            }
        }
        return b.toString();
    }
    String displayName(Uri u) {
        try (android.database.Cursor c = getContentResolver().query(u, null, null, null, null)) {
            if (c != null && c.moveToFirst()) {
                int i = c.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME);
                if (i >= 0) return c.getString(i);
            }
        } catch (Exception ignored) {}
        return u.getLastPathSegment() == null ? "audio" : u.getLastPathSegment();
    }
    String stripExtension(String s) { int p = s.lastIndexOf('.'); return p > 0 ? s.substring(0, p) : s; }
    String safeName(String s) {
        String x = s == null ? "audio" : s.replaceAll("[^a-zA-Z0-9А-Яа-я._-]", "_");
        return x.isEmpty() ? "audio" : x;
    }
    void broadcastProgress(int p, String s, boolean done) {
        // Persist the exact counters so the UI can recover if Android temporarily unregisters
        // its activity receiver while the app is in the background.
        android.content.SharedPreferences state = getSharedPreferences("split_checkpoint", MODE_PRIVATE);
        state.edit().putInt("ui_progress", Math.max(0, Math.min(100, p)))
                .putString("ui_message", s == null ? "" : s)
                .putInt("completed", completedParts).putInt("total", totalParts)
                .putInt("current", currentPart).putBoolean("active", !done)
                .putBoolean("finished", done).apply();
        Intent i = new Intent("SPLIT_PROGRESS");
        i.setPackage(getPackageName());
        i.putExtra("p", p);
        i.putExtra("s", s);
        i.putExtra("finished", done);
        i.putExtra("completed", completedParts);
        i.putExtra("total", totalParts);
        i.putExtra("current", currentPart);
        sendBroadcast(i);
        NotificationManager nm = (NotificationManager)getSystemService(NOTIFICATION_SERVICE);
        if (done) {
            nm.cancel(NOTIF);
            boolean success = s != null && s.startsWith("Готово!");
            String title = success ? "Конвертация завершена" : ((s != null && s.startsWith("Ошибка:")) ? "Ошибка конвертации" : "Конвертация остановлена");
            String detail = success ? ("Успешно создано частей: " + completedParts) : (s == null ? "Обработка завершена" : s);
            Intent open = new Intent(this, MainActivity.class);
            open.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            PendingIntent pi = PendingIntent.getActivity(this, 778, open, PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0));
            Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(this, "split_done") : new Notification.Builder(this);
            Notification finishedNote = b.setContentTitle(title).setContentText(detail).setStyle(new Notification.BigTextStyle().bigText(detail))
                    .setSmallIcon(success ? android.R.drawable.ic_media_play : android.R.drawable.ic_dialog_info)
                    .setContentIntent(pi).setAutoCancel(true).build();
            nm.notify(NOTIF + 1, finishedNote);
        } else {
            nm.notify(NOTIF, note(s, p));
        }
    }
    @Override public android.os.IBinder onBind(Intent i) { return null; }
}
