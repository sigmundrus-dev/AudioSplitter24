package com.kuminov.audiosplitter;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Color;
import android.view.View;

/** Decorative audio-spectrum-like conversion progress indicator; bars track actual job progress. */
public final class SignalProgressView extends View {
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private int progress = 0;
    private final int[] levels = {18,27,42,31,55,70,47,34,62,82,58,39,67,91,63,43,74,52,32,61,80,49,28,45,68,37,56,76,41,24,50,72,44,30,60,84,55,35,66,46};
    public SignalProgressView(Context context) {
        super(context);
        setBackgroundColor(Color.rgb(4, 9, 5));
        setLayerType(View.LAYER_TYPE_SOFTWARE, null);
    }
    public void setProgress(int value) { progress = Math.max(0, Math.min(100, value)); invalidate(); }
    @Override protected void onDraw(Canvas c) {
        super.onDraw(c);
        float w=getWidth(), h=getHeight();
        paint.setStyle(Paint.Style.STROKE); paint.setStrokeWidth(1f); paint.setColor(Color.rgb(55,105,55));
        c.drawRect(0.5f,0.5f,w-0.5f,h-0.5f,paint);
        paint.setStrokeWidth(1f); paint.setColor(Color.rgb(32,65,35));
        for(int i=1;i<4;i++) c.drawLine(1,h*i/4f,w-1,h*i/4f,paint);
        int n=levels.length; float gap=Math.max(1f,w*0.006f), barW=(w-(n+1)*gap)/n;
        for(int i=0;i<n;i++) {
            float bh=(h-12f)*(levels[i]/100f); float x=gap+i*(barW+gap); float y=(h-bh)/2f;
            boolean active=(i+1)*100f/n <= progress;
            paint.setStyle(Paint.Style.FILL);
            paint.setColor(active ? Color.rgb(110,255,105) : Color.rgb(44,87,44));
            c.drawRoundRect(x,y,x+barW,y+bh,2f,2f,paint);
            if(active){paint.setColor(Color.argb(90,210,255,120));c.drawRect(x,y,x+barW,y+Math.min(3f,bh),paint);}
        }
        paint.setStyle(Paint.Style.STROKE); paint.setStrokeWidth(1.5f); paint.setColor(Color.rgb(220,205,75));
        Path p=new Path();
        for(int i=0;i<n;i++) { float x=gap+i*(barW+gap)+barW/2f; float y=h/2f-(levels[i]/100f)*(h-12f)*0.35f; if(i==0)p.moveTo(x,y);else p.lineTo(x,y); }
        c.drawPath(p,paint);
        paint.setStyle(Paint.Style.FILL); paint.setTextSize(Math.max(10f,h*0.18f)); paint.setColor(Color.rgb(120,255,120));
        c.drawText(progress+"%",Math.max(4f,w-44f),Math.max(13f,h*0.2f),paint);
    }
}
