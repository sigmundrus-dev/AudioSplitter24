package com.kuminov.audiosplitter;

import android.app.*;import android.content.*;import android.graphics.Color;import android.net.Uri;import android.os.*;import android.view.*;import android.widget.*;import java.util.*;

public class MainActivity extends Activity {
  static final int PICK_INPUT=10,PICK_DIR=11;
  TextView inputLabel,folderLabel,status; EditText duration,overlap; Spinner bitrate,format; ProgressBar progress; Uri inputUri,folderUri; Button split,cancel,playSource;
  int green=Color.rgb(102,255,102), amber=Color.rgb(255,190,60), dark=Color.rgb(12,12,12);
  @Override public void onCreate(Bundle b){super.onCreate(b); buildUi();}
  TextView tv(String s,int sp){TextView t=new TextView(this);t.setText(s);t.setTextColor(green);t.setTextSize(sp);t.setPadding(10,7,10,7);return t;}
  Button btn(String s){Button b=new Button(this);b.setText(s);b.setTextColor(green);b.setAllCaps(false);return b;}
  void buildUi(){
    LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(8,8,8,8);root.setBackgroundColor(dark);
    TextView title=tv("◈ WINAMP AUDIO SPLITTER ◈",20);title.setTextColor(amber);title.setGravity(Gravity.CENTER);root.addView(title,new LinearLayout.LayoutParams(-1,55));
    inputLabel=tv("Файл: не выбран",14);root.addView(inputLabel);Button pick=btn("ОТКРЫТЬ MP3 / M4A");root.addView(pick);pick.setOnClickListener(v->{Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("audio/*");i.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(i,PICK_INPUT);});
    playSource=btn("▶ ВОСПРОИЗВЕСТИ ИСХОДНИК");root.addView(playSource);playSource.setEnabled(false);playSource.setOnClickListener(v->play(inputUri));
    folderLabel=tv("Папка: не выбрана",14);root.addView(folderLabel);Button dir=btn("ВЫБРАТЬ ПАПКУ");root.addView(dir);dir.setOnClickListener(v->{Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_WRITE_URI_PERMISSION|Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);startActivityForResult(i,PICK_DIR);});
    LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.HORIZONTAL);
    duration=new EditText(this);duration.setHint("30");duration.setTextColor(green);duration.setHintTextColor(Color.GRAY);duration.setInputType(2|8192);row.addView(duration,new LinearLayout.LayoutParams(0,60,1));
    overlap=new EditText(this);overlap.setHint("0");overlap.setTextColor(green);overlap.setHintTextColor(Color.GRAY);overlap.setInputType(2|8192);row.addView(overlap,new LinearLayout.LayoutParams(0,60,1));root.addView(row);
    TextView labels=tv("минут на часть                         секунд перекрытия",11);root.addView(labels);
    format=new Spinner(this);format.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"MP3","M4A"}));root.addView(format);
    bitrate=new Spinner(this);bitrate.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"64k","96k","128k","160k","192k","256k","320k"}));root.addView(bitrate);
    split=btn("▶ НАРЕЗАТЬ");root.addView(split);cancel=btn("■ ОТМЕНА");root.addView(cancel);cancel.setEnabled(false);
    progress=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);progress.setMax(100);root.addView(progress,new LinearLayout.LayoutParams(-1,30));status=tv("Готов",13);root.addView(status);
    split.setOnClickListener(v->startSplit());cancel.setOnClickListener(v->{send("CANCEL");cancel.setEnabled(false);status.setText("Отмена...");});
    setContentView(root);
  }
  void startSplit(){if(inputUri==null||folderUri==null){toast("Выберите файл и папку");return;}int mins=parse(duration,30),ov=parse(overlap,0);String br=bitrate.getSelectedItem().toString(),fmt=format.getSelectedItem().toString();Intent i=new Intent(this,SplitService.class);i.setAction("START");i.putExtra("input",inputUri.toString());i.putExtra("folder",folderUri.toString());i.putExtra("minutes",mins);i.putExtra("overlap",ov);i.putExtra("bitrate",br);i.putExtra("format",fmt);if(Build.VERSION.SDK_INT>=26)startForegroundService(i);else startService(i);split.setEnabled(false);cancel.setEnabled(true);status.setText("Подготовка...");}
  int parse(EditText e,int d){try{return Math.max(0,Integer.parseInt(e.getText().toString().trim()));}catch(Exception x){return d;}}
  void send(String a){Intent i=new Intent(this,SplitService.class);i.setAction(a);if(Build.VERSION.SDK_INT>=26)startForegroundService(i);else startService(i);}
  void play(Uri u){try{android.media.MediaPlayer p=new android.media.MediaPlayer();p.setDataSource(this,u);p.setOnCompletionListener(android.media.MediaPlayer::release);p.prepare();p.start();}catch(Exception e){toast("Не удалось воспроизвести");}}
  void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}
  @Override protected void onActivityResult(int r,int c,Intent d){super.onActivityResult(r,c,d);if(c!=RESULT_OK||d==null)return;if(r==PICK_INPUT){inputUri=d.getData();getContentResolver().takePersistableUriPermission(inputUri,d.getFlags()&(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_WRITE_URI_PERMISSION));inputLabel.setText("Файл: "+inputUri.getLastPathSegment());playSource.setEnabled(true);}else if(r==PICK_DIR){folderUri=d.getData();getContentResolver().takePersistableUriPermission(folderUri,d.getFlags()&(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_WRITE_URI_PERMISSION));folderLabel.setText("Папка: "+folderUri.getLastPathSegment());}}
  @Override protected void onResume(){super.onResume();new Handler().postDelayed(new Runnable(){public void run(){Intent i= new Intent("SPLIT_STATUS");sendBroadcast(i);new Handler().postDelayed(this,800);}},800);}
  public void update(int p,String s){runOnUiThread(()->{progress.setProgress(p);status.setText(s);if(p>=100){split.setEnabled(true);cancel.setEnabled(false);}});}
  final BroadcastReceiver rx=new BroadcastReceiver(){public void onReceive(Context c,Intent i){update(i.getIntExtra("p",0),i.getStringExtra("s"));}};
  @Override protected void onStart(){super.onStart();registerReceiver(rx,new android.content.IntentFilter("SPLIT_PROGRESS"),Context.RECEIVER_NOT_EXPORTED);}
  @Override protected void onStop(){try{unregisterReceiver(rx);}catch(Exception ignored){}super.onStop();}
}
